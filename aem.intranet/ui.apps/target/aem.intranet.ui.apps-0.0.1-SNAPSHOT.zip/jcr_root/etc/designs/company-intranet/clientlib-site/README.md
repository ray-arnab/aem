
This client library should contain general styles and scripts. Everything specific to components should be placed in client libraries below the corresponding components.
